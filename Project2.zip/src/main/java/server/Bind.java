package server;


import java.util.ArrayList;

public class Bind {
    public static ArrayList<String> usernames = new ArrayList<>();
    public static ArrayList<Communication> communications = new ArrayList<Communication>();
}
